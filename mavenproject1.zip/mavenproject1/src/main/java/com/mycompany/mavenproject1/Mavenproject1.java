/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author HP
 */
public class Mavenproject1 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Login>users = new ArrayList<>();//Store a list of users
                
        System.out.println("\n Welcome to our chat app 2026! Select option below:");
        
        while(true){
            //disply menu after each action
            System.out.println("\nMain Menu:");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.println("Choose an option:");
            
            int choice = scanner.nextInt();
            scanner.nextLine();//consume newline
            
            switch(choice){
                case 1://Registration
                    System.out.print("Enter username:");
                    String username = scanner.nextLine();
                    System.out.println("Username successfuly captured!");
                    //validation of username
                    boolean validUsername = username.contains("_")&&username.length()<=5;
                    if(!validUsername){
                        System.out.println("Username must contain at least one underscore and be no longer than 5 characters long");
                        break;
                        
                    }
                    System.out.println("Enter password:");
                    String password = scanner.nextLine();
                    System.out.println("Password successfully captured!");
                    //validate password
                    boolean validPassword=password.length()>8 && password.matches(".*[A-Z]*")&& password.matches(".*\\d*") &&
                            password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
                    if(!validPassword){
                        System.out.println("Password must be at least 8 charactes long");
                        break;
                    }
                    System.out.print("Enter a SA phone number:(e.g. +278311111111):");
                    String phoneNumber = scanner.nextLine();
                    System.out.println("Cellphone number is successfully added!");
                    //validate phone number
                    String regex ="\\+27[6-8]\\(8)";
                    if(!phoneNumber.matches(regex)){
                        System.out.println("Invalid phone number format! use +27xxxxxxxx");
                        break;
                    }
                    //check if the user already exists
                    boolean userExists = users.stream().anyMatch(u ->u.getUsername().equals(username));
                    if(userExists){
                        System.out.println("Username already exists. Please choose another username. ");
                        break;
                    }
                    //add the new user
                    users.add(new Login(username, password, phoneNumber));
                    System.out.println("User registered successfully");
                    //Welcome the user and transistion to login
                    System.out.println("Welcome "+ username + "!You can now log in ");
                    System.out.println("Redirecting yout to login page.........\n");
                    
                    //immediately prompt the user to login
                    promptLogin(scanner,users);
                    break;
                    
                    case 2://login
                    if(users.isEmpty()){
                    System.out.println("No users are registered yet.Please register first.");
                    break;
                 }
                //prompt the user to login 
                promptLogin(scanner,users);
                break;
            
                case 3://Exit
                System.out.println("Goodbye!!");
                scanner.close();
                return;
                
                default:
                    System.out.println("Invalid option, Please choose 1,2 or 3");
            }        
            
        } 
    }
    //method to handle login logic
    private static void promptLogin(Scanner scanner,ArrayList<Login>users){
     System.out.println("Enter username:");
     String enteredUsername = scanner.nextLine();
     System.out.println("Enter password:");
     String enteredPassword = scanner.nextLine();
     //find user and attempt login
     Login user = users.stream().filter(u->u.getUsername().equals(enteredUsername)).findFirst().orElse(null);
     
     boolean loginStatus = user != null && user.loginUser(enteredPassword);
     System.out.println(user !=null? user.returnLoginStatus(loginStatus):"User not Found.");
             
}
}
//Login class
class Login{
    public String username;
    public String passwordHash;
    public String phoneNumber;
    public byte[]salt;
    
    public Login(String username, String password, String phoneNumber){
        this.username = username;
        this.salt = generateSalt();
        this.passwordHash= hashPassword(password,salt);
        this.phoneNumber = phoneNumber;
    }
    public String getUsername(){
        return username;
    }
    public boolean loginUser(String enteredPassword){
        return this.passwordHash.equals(hashPassword(enteredPassword, salt));
}
    public String returnLoginStatus(boolean status){
        return status?"Login successfully! ":"Invalidusername or password.";
    }
    //hash password with salt using SHA-256
    private String hashPassword(String password, byte[]salt){
        try{
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);//add salt to the the hash
            byte[]hash=md.digest(password.getBytes());
            StringBuilder hexString= new StringBuilder();
            for(byte b: hash){
                hexString.append(String.format("%02x", b));
                
            }
           return hexString.toString();
        
    }catch(NoSuchAlgorithmException e){
        throw new RuntimeException("Error hashing password", e);
    }
    
    }    
   //generate a random salt for password hashing
    private byte[]generateSalt(){
        try{
            SecureRandom random = new SecureRandom();
            byte[]salt= new byte[16];
            random.nextBytes(salt);
            return salt;
            
        }catch(Exception e){
            throw new RuntimeException("Error generating salt",e);
        }
    }
    
}


